//
//  NewsItem.swift
//  HealthApp
//
//  Created by Connor Easton on 3/30/21.
//

import Foundation
import UIKit

class NewsItem {
    var source:String?
    var title:String?
    var URL:String?
    var imageUrl:String?
    var image: UIImage?
    
}


